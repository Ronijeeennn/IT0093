# Campus Companion — Profile Photos and Campus Landmarks

UIKit / storyboard app updated for Parts 1–3: a persistent student profile photo, a Remove Photo button, and a Campus Events map with two campus landmarks and a distance label. Existing welcome preferences, REST fetching, Codable decoding, Core Data storage, local add, swipe-to-delete, and announcement detail navigation are retained.

## Open and run

1. Extract the ZIP fully. Open `CampusCompanion.xcodeproj` in Xcode on your Mac.
2. Select the **CampusCompanion** scheme and an iPhone Simulator (iOS 15 or later).
3. Press **Command+B** to build, then **Command+R** to run. No packages or API keys are required.
4. Open **Campus Announcements**. This initially reads the local store without making a request.
5. Tap the circular-arrow **Refresh** button next to **+**. Dismiss the **Server Reached** alert to inspect the updated rows.
6. Open the Xcode debug console with **Shift+Command+Y** to see the byte count, actual raw JSON, decoded item count, or a diagnostic if the request fails.

For a real iPhone, select your own signing team in Signing & Capabilities. Simulator runs do not require a personal device signing setup.

## New photo and map features (Parts 1–3)

The uploaded M5 source did not yet contain Parts 1 and 2. This update includes those foundations and the Part 3 challenge, with storyboard outlets and actions already connected. It also restores the accidentally commented-out `titleLabel` outlet used by the existing screen.

- **Change Photo:** opens the system `PHPickerViewController`, restricted to one image. Cancel leaves the current photo intact. Results return to the main queue before UIKit updates.
- **Persistence:** writes JPEG data at quality 0.8 to the fixed `Documents/profilePhoto.jpg` path with an atomic write, then restores that file on launch. Writes and removals use `do/catch` and log specific failures; failures also show an alert while the profile screen is visible.
- **Remove Photo:** calls `FileManager.default.removeItem(at:)`, then resets the image to `person.crop.circle`. The button starts disabled and is enabled only while a saved file exists and no selection is loading. Failed deletion preserves the existing photo.
- **Campus Events:** both **Explore Campus** and an announcement detail show a scrollable detail screen with the map below the existing text. Blue **Campus** and purple **Campus Library** markers have separate titles, tappable callouts, and required display priority. The map fits both after layout and rotation.
- **Distance:** the retained `CLLocationManager` requests one location only after authorization is granted. The label measures meters to `CampusLocation.coordinate`, regardless of which pin is selected. Denied, restricted, unknown, and failed-location states have visible messages.
- **Privacy:** `Info.plist` includes `NSLocationWhenInUseUsageDescription` specifically for the Campus Events distance feature. The system photo picker does not require adding photo-library access permission for this selection flow.

### Coordinates used by this exercise

| Constant | Latitude | Longitude | Purpose |
| --- | --- | --- | --- |
| `CampusLocation.coordinate` | 14.6255 | 121.0034 | Original coordinate supplied in the lab guide; the only distance destination |
| `LibraryLocation.coordinate` | 14.6263 | 121.0042 | Example nearby library landmark for the challenge |

The library coordinate is a sample, not a verified building location. Edit the two named constants in `DetailViewController.swift` if your instructor supplies actual campus coordinates.

### Quick verification on your Mac

1. Build and run. On first launch, confirm the placeholder is visible and **Remove Photo** is disabled.
2. Tap **Change Photo**, choose an image, and confirm it appears. Stop the app and run again; the photo should return automatically.
3. Tap **Remove Photo**. Confirm the placeholder returns and the button is disabled. Stop and relaunch again; the removed photo must stay removed.
4. Tap **Explore Campus**, or open any announcement. Confirm both **Campus** and **Campus Library** are visible, and tap each pin to inspect its title.
5. In Simulator, choose **Features → Location → Custom Location**, enter latitude **14.6255**, longitude **121.0034**, and allow location access. Reopen the detail screen if it had already requested a location. The distance should be near **0 meters**.
6. Repeat with latitude **14.6263**, longitude **121.0042**. Reopen the detail screen; the label should be approximately **124 meters from campus**, not zero at the library. Selecting either pin must leave the label unchanged.

See `Submission/Part3_Verification.md` for the full photo, permission, and layout checklist and the limits of checks performed here.

## Feed

The exact supplied endpoint is defined only once, in `RemoteEndpoint.announcements`:

```
https://raw.githubusercontent.com/vonn-dev/campus-companion-api/refs/heads/main/announcements.json
```

The feed must return a top-level JSON array. Each object requires string `title`, `date`, and `category` values. `location`, `priority`, `priorityLevel`, and `postedBy` are optional string fields. Either `priority` or `priorityLevel` supplies the displayed Priority Level, with `priorityLevel` taking precedence. Missing locations display **Not specified**; missing priority uses the existing **Normal** default. The client cannot add missing fields to a remote GitHub repository. If the real feed omits Location or Priority Level, its owner must add them for real server values to appear.

This example documents the supported structure; it is not a copy of the live response:

```json
[
  {
    "title": "Campus Fair",
    "date": "October 24, 2026",
    "category": "Student Affairs",
    "location": "Main Auditorium",
    "priority": "High",
    "postedBy": "Student Affairs Office"
  }
]
```

## Organization

| Folder / file | Purpose |
| --- | --- |
| `CampusCompanion/App/` | Existing app lifecycle and Core Data stack |
| `CampusCompanion/Controllers/` | Welcome, announcements, and detail screens |
| `CampusCompanion/Models/AnnouncementDTO.swift` | Separate Codable network object |
| `CampusCompanion/Models/CampusCompanion.xcdatamodeld/` | Original M4 model and current V5 model |
| `CampusCompanion/Views/AnnouncementCell.swift` | Wrapping, aligned announcement rows |
| `CampusCompanion/Base.lproj/Main.storyboard` | Screens, Refresh action, outlets, layout constraints |
| `Submission/Reflection.txt` | Existing Exercise 5 reflection for review |
| `Submission/Part3_Verification.md` | New feature checklist and validation limits |
| `Submission/Verification_and_Screenshots.md` | Run checklist and required screenshot instructions |

## Request → decode → persist → display

Refresh starts one asynchronous `URLSession.shared.dataTask` and calls `resume()`. The handler checks transport error, HTTP 200–299, and non-nil data in that order, then prints the actual UTF-8 JSON. `JSONDecoder` decodes `[AnnouncementDTO]` inside `do/catch`. `DispatchQueue.main.async` moves persistence and UIKit work to the main queue. `replaceAnnouncements(with:)` deletes existing records, copies every DTO field, saves once, calls the original `loadAnnouncements()`, and reloads the table. Only a successful save produces the **Server Reached** alert with `data.count`.

The button is disabled while a request is pending and restored on every exit. Requests bypass the local response cache and time out after 30 seconds. Offline, HTTP, or decoding failures print diagnostics and leave the existing rows untouched; a save failure rolls back the replacement. A successful empty feed remains empty on relaunch instead of restoring the seed data.

**Refresh replaces the entire local announcement collection, including local additions**, as required by the lab. Repeated refreshes do not append duplicates.

## Challenge fields and layout

- Location is added to the V5 Core Data model with a migration default. The original model is preserved and the current model is selected in both Xcode and `.xccurrentversion`.
- Priority Level uses the existing Core Data `priority` attribute from M4, preserving previous priorities.
- Both fields are copied during synchronization and shown in the list and detail view.
- Announcement rows use a vertical stack, consistent 16-point outer spacing, aligned text, multiline labels, Dynamic Type, and automatic row heights.
- Urgent, High, and Critical priorities use red text/icon treatment as well as a written level.
- The centered welcome heading and form are retained inside a scroll view for smaller screens.

## Validation limits

The updated files were checked structurally for XML/plist validity, storyboard connections, source membership, model selection, and archive integrity. Parts 1–3 source paths and the separation of the landmark coordinates were also reviewed. This workspace does not provide Xcode, an Apple SDK, or an iOS Simulator, so a full build, runtime layout review, migration test, and authentic submission screenshots must be completed on your Mac. The live GitHub response was blocked by this environment, so its exact current schema, item count, and byte count could not be verified. No screenshots or live results have been fabricated.
