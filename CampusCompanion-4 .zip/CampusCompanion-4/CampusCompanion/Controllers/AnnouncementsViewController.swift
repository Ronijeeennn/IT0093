//
//  AnnouncementsViewController.swift
//  CampusCompanion
//

import UIKit
import CoreData

class AnnouncementsViewController: UITableViewController {

    // RONIJEN: - Exercise 4: Core Data-backed data source
    private var announcements: [CampusAnnouncement] = []
    private var selectedAnnouncement: CampusAnnouncement?

    private var context: NSManagedObjectContext {
        (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        seedInitialAnnouncementsIfNeeded()
        loadAnnouncements()
    }

    // RONIJEN: - Core Data: seed & fetch
    private func seedInitialAnnouncementsIfNeeded() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        let existingCount = (try? context.count(for: request)) ?? 0
        guard existingCount == 0 else { return }

        let seeds: [(title: String, date: String, category: String, priority: String, postedBy: String)] = [
            ("Enrollment Period Extended", "August 3, 2026", "Registrar",
             "Normal", "Registrar's Office"),
            ("Library Hours Extended for Finals", "August 5, 2026", "Library",
             "Normal", "University Library"),
            ("Career Fair 2026", "August 10, 2026", "Career Center",
             "Normal", "Career Center"),
            ("Student Council Elections", "August 14, 2026", "Student Affairs",
             "Normal", "Student Affairs Office"),
            ("Campus Wi-Fi Maintenance Notice", "August 16, 2026", "IT Services",
             "Urgent", "IT Services"),
            ("Intramural Sports Sign-Up", "August 20, 2026", "Athletics",
             "Normal", "Athletics Office")
        ]

        for seed in seeds {
            let announcement = CampusAnnouncement(context: context)
            announcement.title = seed.title
            announcement.date = seed.date
            announcement.category = seed.category
            announcement.priority = seed.priority
            announcement.postedBy = seed.postedBy
        }
        try? context.save()
    }

    private func loadAnnouncements() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]
        let fetched = (try? context.fetch(request)) ?? []

        // "date" is stored as text ("August 3, 2026"), so a plain string sort would put
        // "August 10" before "August 3". Re-order by the real calendar date.
        announcements = fetched.sorted { first, second in
            let firstDate = calendarDate(from: first.date ?? "")
            let secondDate = calendarDate(from: second.date ?? "")
            if firstDate != secondDate { return firstDate < secondDate }
            return (first.title ?? "") < (second.title ?? "")
        }
        tableView.reloadData()
    }

    private func calendarDate(from text: String) -> Date {
        let fixedFormatter = DateFormatter()
        fixedFormatter.locale = Locale(identifier: "en_US_POSIX")
        fixedFormatter.dateFormat = "MMMM d, yyyy"
        if let date = fixedFormatter.date(from: text) { return date }

        // New announcements are stamped with the device's locale (.long style).
        let localizedFormatter = DateFormatter()
        localizedFormatter.dateStyle = .long
        localizedFormatter.timeStyle = .none
        return localizedFormatter.date(from: text) ?? .distantFuture
    }

    // RONIJEN: - Actions
    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Announcement",
                                      message: "Enter a title and category.",
                                      preferredStyle: .alert)
        alert.addTextField { textField in textField.placeholder = "Title" }
        alert.addTextField { textField in textField.placeholder = "Category" }

        let saveAction = UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let self = self,
                  let titleText = alert?.textFields?[0].text, !titleText.isEmpty,
                  let categoryText = alert?.textFields?[1].text, !categoryText.isEmpty else { return }

            let newAnnouncement = CampusAnnouncement(context: self.context)
            newAnnouncement.title = titleText
            newAnnouncement.date = DateFormatter.localizedString(from: Date(),
                                                                 dateStyle: .long, timeStyle: .none)
            newAnnouncement.category = categoryText
            newAnnouncement.priority = "Normal"
            newAnnouncement.postedBy = "Student"
            try? self.context.save()
            self.loadAnnouncements()
        }
        alert.addAction(saveAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    // RONIJEN: - UITableViewDataSource
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return announcements.count
    }

    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "AnnouncementCell", for: indexPath)
            as? AnnouncementCell else {
            return UITableViewCell()
        }
        cell.configure(with: announcements[indexPath.row])
        return cell
    }

    // RONIJEN: - Exercise 4, Part 3: swipe-to-delete
    override func tableView(_ tableView: UITableView,
                            canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle,
                            forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }

        let announcementToDelete = announcements[indexPath.row]
        context.delete(announcementToDelete)
        try? context.save()
        announcements.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .automatic)
    }

    // RONIJEN: - UITableViewDelegate
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedAnnouncement = announcements[indexPath.row]
        performSegue(withIdentifier: "ShowAnnouncementDetailSegue", sender: self)
    }

    // RONIJEN: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowAnnouncementDetailSegue",
              let destination = segue.destination as? DetailViewController,
              let announcement = selectedAnnouncement else { return }
        destination.announcement = announcement
    }
}
