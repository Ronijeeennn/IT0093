# Campus Companion — M3 (Exercise 3)

Campus Announcements: UITableView & custom cells (Parts 1–3). Includes everything from M2.

## Open
Double-click `CampusCompanion.xcodeproj`, choose an iPhone simulator, press ⌘R.

## Folder layout (Xcode folders, auto-synced)
- `App/` — AppDelegate, SceneDelegate
- `Controllers/` — ViewController, DetailViewController, AnnouncementsViewController
- `Models/` — CampusAnnouncement (title, date, category, priority, postedBy)
- `Views/` — AnnouncementCell (custom UITableViewCell)
- `Base.lproj/Main.storyboard` — Nav → Welcome → (Detail | Announcements list → Detail)

## Identifiers (must match exactly)
- Cell reuse identifier: `AnnouncementCell`
- Segues: `ShowDetailSegue` (Explore Campus), `ShowAnnouncementDetailSegue` (row tap)
- "Campus Announcements" button uses a direct Show segue (no identifier)

## Test checklist
1. Campus Announcements → 6 rows with megaphone icons; "Campus Wi-Fi Maintenance Notice" is red with an alert icon.
2. Scroll up/down repeatedly → only the Wi-Fi row stays red (cell reuse is correct).
3. Tap a row → Detail shows title, category, date, priority, posted by.
4. Back to welcome → Explore Campus flow still shows the personalized welcome message.
