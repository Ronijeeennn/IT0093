//
//  ViewController.swift
//  CampusCompanion
//
//  Created by ANTONIO, RONIJEN on 9/19/26.
//

import UIKit

class ViewController: UIViewController {

    // Connect this to the subtitle label in Main.storyboard
    @IBOutlet weak var subtitleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Optional: initial subtitle text if you want to ensure a default
        if subtitleLabel.text?.isEmpty ?? true {
            subtitleLabel.text = "Your campus life, simplified."
        }
    }

    // Connect the "Get Started" button Touch Up Inside to this action
    @IBAction func getStartedTapped(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }
}
